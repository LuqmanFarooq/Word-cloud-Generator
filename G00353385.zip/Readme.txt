******************************WordCloud Generator******************************
Description of the program:
A program to generate word cloud image by extracting word from files or url.
Functionality:
program runs presenting the following Menu options to the user.
* if user selects 1 it will be asked to enter the file name with extension eg(.txt).
* if user selects 2 it will be asked to enter url.
* To enter the max number of words to show in the wordcloud image user have to enter 3.
* To enter the image file name user will have to enter 4.
* To exit the program user will have to enter 5 and after program ends the image file will be generated
with the specified file name,maximum no of words.
Extra:
Random Method for different font size and placements.
